# Tugas 2 - Progjar E
```
Nama : Muhammad Ryanda Nugraha M
NRP : 05111640000180
```
## Deskripsi Tugas

![DeskripsiTugas](DeskripsiTugas.jpg)


## Cara Penggunaan
Berikut ini adalah instruksi tentang cara penggunaan script ini :

### Linux
- Jalankan server.py
- Jalankan run_all_client.sh
- File yang diterima client akan disimpan di File_Client1, File_Client2, File_Client3, File_Client4 dan File_Client5

### Windows (Tidak Direkomendasikan karena data terkadang corrupt saat transfer)
- Jalankan server.py
- Jalankan semua satu persatu
- File yang diterima client akan disimpan di File_Client1, File_Client2, File_Client3, File_Client4 dan File_Client5


