python client1.py &
python client2.py &
python client3.py &
python client4.py &
python client5.py &
